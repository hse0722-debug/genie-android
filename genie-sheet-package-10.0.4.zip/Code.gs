/** 지니 시트 연결 서버 10.0.4 — 이 파일은 Apps Script에만 설치합니다. */
const GENIE_SEED_ID='1KS0avSMsGkba5zeDb2IZ_v2p1bJGW7uXm5hcDV_2q24';
const GENIE_ACCOUNT_ID='14SWMDCFfxYGFAuoTMxahDKTcranKXmyfVDu31SH7OEw';
function onOpen(){SpreadsheetApp.getUi().createMenu('지니 연동').addItem('1. 초기 설정','setupGenie').addItem('원격제어 탭 만들기','createRemoteControlSheets').addItem('원격제어 명령 다시 전송','resendRemoteCommand').addItem('계정 파일 추가 허용','allowAccountFile').addToUi();}
function setupGenie(){const p=PropertiesService.getScriptProperties();if(!p.getProperty('ACCOUNT_IDS'))p.setProperty('ACCOUNT_IDS',JSON.stringify([GENIE_ACCOUNT_ID]));p.setProperty('SEED_ID',GENIE_SEED_ID);if(!p.getProperty('SEED_GID'))p.setProperty('SEED_GID','0');SpreadsheetApp.getUi().alert('설정 완료. 시드 파일의 gid가 0이 아니면 프로젝트 설정 → 스크립트 속성의 SEED_GID를 수정하세요. 다음으로 웹 앱을 배포하세요.');}
function allowAccountFile(){const ui=SpreadsheetApp.getUi(),r=ui.prompt('계정 파일 추가','허용할 Google 시트 주소 또는 파일 ID',ui.ButtonSet.OK_CANCEL);if(r.getSelectedButton()!==ui.Button.OK)return;const value=r.getResponseText().trim(),id=(value.match(/\/d\/([\w-]+)/)||[])[1]||value;if(!/^[\w-]{20,}$/.test(id))throw Error('주소를 확인하세요.');SpreadsheetApp.openById(id);const p=PropertiesService.getScriptProperties(),ids=JSON.parse(p.getProperty('ACCOUNT_IDS')||'[]');p.setProperty('ACCOUNT_IDS',JSON.stringify([...new Set([...ids,id])]));ui.alert('허용했습니다. 같은 파일의 새 탭은 추가 설정 없이 사용할 수 있습니다.');}
function hashKey_(value){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(value)).map(n=>('0'+((n+256)%256).toString(16)).slice(-2)).join('');}
function json_(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);}
function doGet(){return json_({ok:true,service:'genie-sheet',version:'10.0.4',message:'시트 연결용 POST 요청을 받습니다.'});}
function seeds_(p){const book=SpreadsheetApp.openById(p.getProperty('SEED_ID')||GENIE_SEED_ID),sheet=book.getSheets().find(s=>s.getSheetId()===Number(p.getProperty('SEED_GID')||0));if(!sheet)throw Error('시드 탭이 없습니다.');const cells=sheet.getRange('C3:D7').getDisplayValues(),out={};for(const [key,r,c] of [['album',0,0],['song',0,1],['mv',3,0],['artist',3,1]]){const name=String(cells[r][c]).trim(),sid=String(cells[r+1][c]).trim();if(!name&&!sid){out[key]={name:'',sid:''};continue;}if(!name||!/^\d+$/.test(sid))throw Error(key+' 이름·숫자 시드를 함께 입력하세요.');out[key]={name,sid};}return out;}
function leaseKey_(req,id){return 'LEASE_'+hashKey_('account:'+id);}

function createRemoteControlSheets(){
 const book=SpreadsheetApp.getActiveSpreadsheet(),p=PropertiesService.getScriptProperties();
 p.setProperty('CONTROL_BOOK_ID',book.getId());
 let controls=book.getSheetByName('리모컨제어');if(!controls)controls=book.insertSheet('리모컨제어');
 controls.getRange(1,1,1,4).setValues([['대상','명령','요청번호','설명']]);
 if(controls.getLastRow()<2)controls.getRange(2,1,1,4).setValues([['전체','실행 허용',String(Date.now()),'모든 헬퍼에 적용. 중단 확인은 리모컨상태 탭에서 확인하세요.']]);
 const validation=SpreadsheetApp.newDataValidation().requireValueInList(['실행 허용','중단','중단 후 계정 다시 불러오기'],true).setAllowInvalid(false).build();
 controls.getRange(2,2,Math.max(1,controls.getMaxRows()-1),1).setDataValidation(validation);controls.setFrozenRows(1);
 let status=book.getSheetByName('리모컨상태');if(!status)status=book.insertSheet('리모컨상태');
 status.getRange(1,1,1,7).setValues([['기기 ID','헬퍼','상태','마지막 확인','현재 아이디','확인한 명령','비고']]);status.setFrozenRows(1);
 SpreadsheetApp.getUi().alert('리모컨제어 탭에서 전체 또는 헬퍼별 명령을 선택하세요. 리모컨상태 탭의 중단 확인을 본 뒤 계정을 수정하고, 중단 후 계정 다시 불러오기를 선택하세요. 실행 허용으로 바꿔도 자동으로 시작하지 않습니다.');
}
function onEdit(e){if(!e?.range||e.range.getSheet().getName()!=='리모컨제어')return;if(e.range.getColumn()>2||e.range.getColumn()+e.range.getNumColumns()-1<2)return;const sheet=e.range.getSheet();for(let row=Math.max(2,e.range.getRow());row<e.range.getRow()+e.range.getNumRows();row++)sheet.getRange(row,3).setValue(String(Date.now())+'-'+row);}
function resendRemoteCommand(){const sheet=SpreadsheetApp.getActiveSheet(),row=sheet.getActiveRange().getRow();if(sheet.getName()!=='리모컨제어'||row<2){SpreadsheetApp.getUi().alert('리모컨제어 탭에서 다시 보낼 명령의 행을 선택하세요.');return;}sheet.getRange(row,3).setValue(String(Date.now())+'-'+row);}
function rememberHelpers_(rows,p){const values={};for(const name of [...new Set(rows.map(r=>r.helper))])values['HELPER_'+hashKey_(name)]=name;if(Object.keys(values).length)p.setProperties(values);}
function safeCell_(value){const text=String(value??'').slice(0,500);return /^[=+@-]/.test(text)?"'"+text:text;}
function controlBook_(p){const id=p.getProperty('CONTROL_BOOK_ID');if(!id)throw Error('관리 시트에서 지니 연동 → 원격제어 탭 만들기를 먼저 실행하세요.');return SpreadsheetApp.openById(id);}
function readControl_(helper,p){
 if(!p.getProperty('HELPER_'+hashKey_(helper)))throw Error('계정 시트의 시간·헬퍼를 먼저 불러오세요.');
 const book=controlBook_(p),sheet=book.getSheetByName('리모컨제어');if(!sheet)throw Error('리모컨제어 탭을 찾을 수 없습니다.');
 const list=sheet.getRange(2,1,Math.max(1,sheet.getLastRow()-1),3).getDisplayValues();
 if(!list.some(r=>String(r[0]).trim()===helper)){sheet.appendRow([safeCell_(helper),'실행 허용',String(Date.now()),'헬퍼별 제어']);list.push([helper,'실행 허용',String(Date.now())]);}
 const relevant=list.filter(r=>['전체',helper].includes(String(r[0]).trim())).map(r=>({target:String(r[0]).trim(),command:String(r[1]).trim(),revision:String(r[2])}));
 if(relevant.filter(r=>r.target==='전체').length!==1||relevant.filter(r=>r.target===helper).length!==1)throw Error('리모컨제어 탭의 전체/헬퍼 행이 없거나 중복됩니다.');
 if(relevant.some(r=>!['실행 허용','중단','중단 후 계정 다시 불러오기'].includes(r.command)))throw Error('리모컨제어 탭의 명령을 확인하세요.');
 return {stop:relevant.some(r=>r.command!=='실행 허용'),reload:relevant.some(r=>r.command==='중단 후 계정 다시 불러오기'),version:relevant.map(r=>r.target+':'+r.revision+':'+r.command).join('|')};
}
function recordClientStatus_(req,control,p){
 if(!/^[\w-]{10,100}$/.test(req.clientId||''))return;
 const sheet=controlBook_(p).getSheetByName('리모컨상태');if(!sheet)throw Error('리모컨상태 탭을 찾을 수 없습니다.');
 const ids=sheet.getLastRow()>1?sheet.getRange(2,1,sheet.getLastRow()-1,1).getDisplayValues().map(r=>r[0]):[];
 let status=req.isRunning?'진행 중':'대기';
 if(control.stop)status=req.isRunning?'중단 요청 대기':'중단 확인 대기';
 if(!req.isRunning&&req.ackVersion===control.version&&control.stop&&['중단 확인','계정 다시 불러오기 완료','계정 다시 불러오기 실패'].includes(req.status))status=req.status;
 const values=[[req.clientId,safeCell_(req.helper),status,Utilities.formatDate(new Date(),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),safeCell_(req.accountId),safeCell_(req.ackVersion||''),safeCell_(req.note||'')]];
 sheet.getRange(ids.includes(req.clientId)?ids.indexOf(req.clientId)+2:sheet.getLastRow()+1,1,1,7).setValues(values);
}

function rows_(sheet,withPasswords=true){const count=sheet.getLastRow()-2;if(count<1)return [];const rows=sheet.getRange(3,1,count,4).getDisplayValues(),passwords=withPasswords?sheet.getRange(3,10,count,1).getValues():[];let time='';return rows.map((r,i)=>{if(String(r[1]).trim())time=String(r[1]).trim();return {row:i+3,number:String(r[0]).trim(),time,helper:String(r[2]).trim(),id:String(r[3]).trim(),password:withPasswords?String(passwords[i][0]??''):''};}).filter(r=>/^\d+$/.test(r.number)&&r.id&&r.helper);}
function pickRows_(req,client,sheet,prepared){const all=prepared||rows_(sheet);if(!all.some(r=>r.helper===String(req.helper)))throw Error('선택한 헬퍼가 C열에 없습니다.');const rows=all.filter(r=>r.helper===req.helper&&r.time===req.time);const seen=new Set();for(const row of rows){if(seen.has(row.id))throw Error('선택 범위에 중복 아이디가 있습니다.');seen.add(row.id);}return rows;}
function handle_(req,client,sheet,p){
 const rows=rows_(sheet,['accounts','start','prepare'].includes(req.action));rememberHelpers_(rows,p);
 if(req.action==='catalog')return {ok:true,title:sheet.getName(),helpers:[...new Set(rows.map(r=>r.helper))],times:[...new Set(rows.map(r=>r.time).filter(Boolean))],pairs:[...new Map(rows.map(r=>[r.helper+'\u0000'+r.time,{helper:r.helper,time:r.time}])).values()]};
 const selected=pickRows_(req,client,sheet,rows);
 if(req.action==='accounts'){const valid=selected.filter(r=>r.password.length>0);return {ok:true,title:sheet.getName(),accounts:valid,excluded:selected.length-valid.length};}
 if(!/^[\w-]{10,100}$/.test(req.jobId||''))throw Error('작업 ID 오류');
 let control;if(['claim','heartbeat','start','prepare'].includes(req.action)){control=readControl_(req.helper,p);recordClientStatus_(req,control,p);if(control.stop)return {ok:false,error:'관리자 원격 중단 명령입니다.',control};}
 const now=Date.now(),requested=req.accounts||[];if(!Array.isArray(requested)||requested.length>2000)throw Error('계정 수 오류');
 const targets=requested.map(id=>{const row=selected.find(r=>r.id===id);if(!row)throw Error('계정 배정·시간이 변경되었습니다. 다시 불러오세요.');return row;});
 if(['start','prepare'].includes(req.action)&&targets.some(r=>!r.password))throw Error('J열 비밀번호가 비어 있습니다.');
 const seedData=req.action==='start'?seeds_(p):null;
 const leases=targets.map(row=>{const key=leaseKey_(req,row.id),value=JSON.parse(p.getProperty(key)||'null');if(value&&value.until>now&&(value.jobId!==req.jobId||value.owner!=='open'))throw Error('다른 기기에서 사용 중인 계정이 있습니다.');return {row,key,value};});
 if(req.action==='release'){for(const item of leases)if(item.value&&item.value.jobId===req.jobId&&item.value.owner==='open')p.deleteProperty(item.key);return {ok:true};}
 if(req.action==='write'){const changes=req.changes;if(!Array.isArray(changes)||changes.length>100)throw Error('기록 수 오류');const columns={down:5,song:6,mv:7,album:8,artist:9};for(const change of changes){const item=leases.find(l=>l.row.id===change.id);if(!item||!columns[change.metric]||!['o','x'].includes(change.value))throw Error('허용되지 않은 결과 기록');}for(const value of ['o','x']){const ranges=changes.filter(c=>c.value===value).map(change=>{const row=leases.find(l=>l.row.id===change.id).row;return String.fromCharCode(64+columns[change.metric])+row.row;});if(ranges.length)sheet.getRangeList(ranges).setValue(value);}SpreadsheetApp.flush();return {ok:true,written:changes.length};}
 const updates={};for(const item of leases)updates[item.key]=JSON.stringify({jobId:req.jobId,owner:'open',until:now+180000});if(leases.length)p.setProperties(updates);
 return {ok:true,count:targets.length,control,...(['start','prepare'].includes(req.action)?{accounts:targets}:{}),...(seedData?{seeds:seedData}:{})};
}
function doPost(e){try{
 const raw=e?.postData?.contents;if(!raw||raw.length>150000)throw Error('요청 크기 오류');const req=JSON.parse(raw),p=PropertiesService.getScriptProperties();
 if(req.action==='seeds')return json_({ok:true,seeds:seeds_(p)});
 if(['control','controlAck'].includes(req.action)){const lock=LockService.getScriptLock();if(!lock.tryLock(10000))throw Error('제어 요청 처리 중입니다.');try{const control=readControl_(String(req.helper||''),p);recordClientStatus_(req,control,p);return json_({ok:true,control});}finally{lock.releaseLock();}}
 if(!['catalog','accounts','claim','heartbeat','write','release','start','prepare'].includes(req.action))throw Error('Apps Script 새 버전 배포를 확인하세요.');
 const ids=JSON.parse(p.getProperty('ACCOUNT_IDS')||'[]');if(!ids.includes(req.spreadsheetId))throw Error('관리자가 허용하지 않은 계정 파일입니다.');
 if(req.action==='release'){const lock=LockService.getScriptLock();if(!lock.tryLock(10000))throw Error('잠금 해제 대기 중입니다.');try{if(!/^[\w-]{10,100}$/.test(req.jobId||'')||!Array.isArray(req.accounts)||req.accounts.length>2000)throw Error('잠금 해제 요청 오류');for(const id of req.accounts){const key=leaseKey_(req,id),value=JSON.parse(p.getProperty(key)||'null');if(value?.jobId===req.jobId&&value.owner==='open')p.deleteProperty(key);}return json_({ok:true});}finally{lock.releaseLock();}}
 const book=SpreadsheetApp.openById(req.spreadsheetId),sheet=book.getSheets().find(s=>s.getSheetId()===Number(req.gid));if(!sheet)throw Error('탭(gid)을 찾을 수 없습니다.');
 const lock=LockService.getScriptLock();if(!lock.tryLock(15000))throw Error('다른 요청을 처리 중입니다. 다시 시도하세요.');try{return json_(handle_(req,null,sheet,p));}finally{lock.releaseLock();}
 }catch(err){return json_({ok:false,error:String(err.message||'시트 요청 실패')});}}
